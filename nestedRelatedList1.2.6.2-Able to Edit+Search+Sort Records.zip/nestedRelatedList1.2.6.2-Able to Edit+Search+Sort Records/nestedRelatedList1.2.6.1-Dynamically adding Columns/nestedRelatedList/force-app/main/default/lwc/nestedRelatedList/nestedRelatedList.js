import { LightningElement, track, api } from 'lwc';
import getParentRecords from '@salesforce/apex/NestedRelatedListController.getParentRecords';
import getChildRecords from '@salesforce/apex/NestedRelatedListController.getChildRecords';
import getGrandchildRecords from '@salesforce/apex/NestedRelatedListController.getGrandchildRecords';
import deleteRecord from '@salesforce/apex/NestedRelatedListController.deleteRecord';
import { ShowToastEvent } from 'lightning/platformShowToastEvent';

export default class NestedRelatedList extends LightningElement {
    @api parentObjectApiName = 'Account';
    @api childObjectApiName = 'Opportunity';
    @api grandchildObjectApiName = 'OpportunityLineItem';
    @api parentFieldset = 'AccountFieldset';
    @api childFieldset = 'OpportunityFieldset';
    @api grandchildFieldset = 'OpportunityLineItemFieldset';

    @track parentRecords = [];
    @track childRecords = [];
    @track grandchildRecords = [];

    @track parentColumns = [];
    @track childColumns = [];
    @track grandchildColumns = [];

    @track expandedParentId = null;
    @track expandedChildId = null;

    @track filteredParentRecords = [];
    @track filteredChildRecords = [];
    @track filteredGrandchildRecords = [];

    @track sortedByParent = '';
    @track sortedDirectionParent = 'asc';
    @track sortedByChild = '';
    @track sortedDirectionChild = 'asc';
    @track sortedByGrandchild = '';
    @track sortedDirectionGrandchild = 'asc';

    @track isEditModalOpen = false;
    @track editRecordId = null;
    @track editObjectApiName = '';

    @track editFieldSet = '';

    connectedCallback() {
        this.loadParentRecords();
    }

    loadParentRecords() {
        getParentRecords({ parentObjectApiName: this.parentObjectApiName, parentFieldset: this.parentFieldset })
            .then(result => {
                this.parentRecords = result.records;
                this.filteredParentRecords = [...this.parentRecords];
                this.parentColumns = this.createColumns(result.columns);
            })
            .catch(error => {
                console.error('Error fetching parent records', error);
            });
    }

    loadChildRecords() {
        getChildRecords({
            childObjectApiName: this.childObjectApiName,
            parentField: 'AccountId',
            parentId: this.expandedParentId,
            childFieldset: this.childFieldset
        })
            .then(result => {
                this.childRecords = result.records;
                this.filteredChildRecords = [...this.childRecords];
                this.childColumns = this.createColumns(result.columns);
            })
            .catch(error => {
                console.error('Error fetching child records', error);
            });
    }

    loadGrandchildRecords() {
        getGrandchildRecords({
            grandchildObjectApiName: this.grandchildObjectApiName,
            childField: 'OpportunityId',
            childId: this.expandedChildId,
            grandchildFieldset: this.grandchildFieldset
        })
            .then(result => {
                this.grandchildRecords = result.records;
                this.filteredGrandchildRecords = [...this.grandchildRecords];
                this.grandchildColumns = this.createColumns(result.columns);
            })
            .catch(error => {
                console.error('Error fetching grandchild records', error);
            });
    }

    createColumns(fieldList) {
        let columns = [];
        fieldList.forEach(field => {
            let column = { label: field.label, fieldName: field.fieldName, sortable: true };
            if (['currency', 'number', 'date', 'datetime', 'email', 'phone', 'boolean', 'percent', 'reference', 'textarea', 'url'].includes(field.type)) {
                column.type = field.type;
            }
            columns.push(column);
        });
        columns.push({
            type: 'action',
            typeAttributes: {
                rowActions: this.getRowActions.bind(this)
            }
        });
        return columns;
    }

    getRowActions(row, doneCallback) {
        const actions = [
            { label: 'Edit', name: 'edit' },
            { label: 'Delete', name: 'delete' },
            { label: 'Show Related', name: 'show_related' }
        ];
        doneCallback(actions);
    }

    handleParentRowAction(event) {
        const actionName = event.detail.action.name;
        const row = event.detail.row;
        switch (actionName) {
            case 'show_related':
                this.expandedParentId = row.Id;
                this.loadChildRecords();
                break;
            case 'edit':
                this.openEditModal(row, this.parentObjectApiName);
                break;
            case 'delete':
                this.deleteRecord(row.Id, this.parentObjectApiName);
                break;
            default:
                break;
        }
    }

    handleChildRowAction(event) {
        const actionName = event.detail.action.name;
        const row = event.detail.row;
        switch (actionName) {
            case 'show_related':
                this.expandedChildId = row.Id;
                this.loadGrandchildRecords();
                break;
            case 'edit':
                this.openEditModal(row, this.childObjectApiName);
                break;
            case 'delete':
                this.deleteRecord(row.Id, this.childObjectApiName);
                break;
            default:
                break;
        }
    }

    handleGrandchildRowAction(event) {
        const actionName = event.detail.action.name;
        const row = event.detail.row;
        switch (actionName) {
            case 'edit':
                this.openEditModal(row, this.grandchildObjectApiName);
                break;
            case 'delete':
                this.deleteRecord(row.Id, this.grandchildObjectApiName);
                break;
            default:
                break;
        }
    }

    openEditModal(row, objectApiName) {
        this.editRecordId = row.Id;
        this.editObjectApiName = objectApiName;
        this.isEditModalOpen = true;
    }

    handleModalClose() {
        this.isEditModalOpen = false;
        this.editRecordId = null;
        this.editObjectApiName = '';
        this.loadParentRecords();
        if (this.expandedParentId) {
            this.loadChildRecords();
        }
        if (this.expandedChildId) {
            this.loadGrandchildRecords();
        }
    }

    deleteRecord(recordId, objectApiName) {
        deleteRecord({ recordId: recordId, objectApiName: objectApiName })
            .then(() => {
                this.showToast('Success', 'Record deleted successfully', 'success');
                this.loadParentRecords();
                if (this.expandedParentId) {
                    this.loadChildRecords();
                }
                if (this.expandedChildId) {
                    this.loadGrandchildRecords();
                }
            })
            .catch(error => {
                this.showToast('Error', 'Error deleting record', 'error');
                console.error('Error deleting record', error);
            });
    }

    refreshData() {
        this.loadParentRecords();
        if (this.expandedParentId) {
            this.loadChildRecords();
        }
        if (this.expandedChildId) {
            this.loadGrandchildRecords();
        }
    }    

    showToast(title, message, variant) {
        this.dispatchEvent(new ShowToastEvent({ title, message, variant }));
    }

    handleParentSearch(event) {
        const searchTerm = event.target.value.toLowerCase();
        this.filteredParentRecords = this.parentRecords.filter(record => {
            return this.filterRecord(record, searchTerm);
        });
    }

    handleChildSearch(event) {
        const searchTerm = event.target.value.toLowerCase();
        this.filteredChildRecords = this.childRecords.filter(record => {
            return this.filterRecord(record, searchTerm);
        });
    }

    handleGrandchildSearch(event) {
        const searchTerm = event.target.value.toLowerCase();
        this.filteredGrandchildRecords = this.grandchildRecords.filter(record => {
            return this.filterRecord(record, searchTerm);
        });
    }    

    filterRecord(record, searchTerm) {
        return Object.values(record).some(value => {
            return value && value.toString().toLowerCase().includes(searchTerm);
        });
    }  
    
    handleParentSort(event) {
        const { fieldName: sortedBy, sortDirection } = event.detail;
        const cloneData = [...this.filteredParentRecords];
        cloneData.sort(this.sortBy(sortedBy, sortDirection === 'asc' ? 1 : -1));
        this.filteredParentRecords = cloneData;
        this.sortedByParent = sortedBy;
        this.sortedDirectionParent = sortDirection;
    }

    handleChildSort(event) {
        const { fieldName: sortedBy, sortDirection } = event.detail;
        const cloneData = [...this.filteredChildRecords];
        cloneData.sort(this.sortBy(sortedBy, sortDirection === 'asc' ? 1 : -1));
        this.filteredChildRecords = cloneData;
        this.sortedByChild = sortedBy;
        this.sortedDirectionChild = sortDirection;
    }

    handleGrandchildSort(event) {
        const { fieldName: sortedBy, sortDirection } = event.detail;
        const cloneData = [...this.filteredGrandchildRecords];
        cloneData.sort(this.sortBy(sortedBy, sortDirection === 'asc' ? 1 : -1));
        this.filteredGrandchildRecords = cloneData;
        this.sortedByGrandchild = sortedBy;
        this.sortedDirectionGrandchild = sortDirection;
    }

    sortBy(field, reverse) {
        return function(a, b) {
            let aValue = a[field];
            let bValue = b[field];

            // Handle null or undefined values
            if (aValue === null || aValue === undefined) aValue = '';
            if (bValue === null || bValue === undefined) bValue = '';

            // Determine the type of the field
            const isNumeric = !isNaN(aValue) && !isNaN(bValue);

            if (isNumeric) {
                // Compare as numbers
                return reverse * ((aValue > bValue) - (bValue > aValue));
            } else {
                // Compare as strings (case-insensitive)
                aValue = aValue.toString().toLowerCase();
                bValue = bValue.toString().toLowerCase();
                return reverse * ((aValue > bValue) - (bValue > aValue));
            }
        };
    }    

    openEditModal(row, objectApiName) {
        this.editRecordId = row.Id;
        this.editObjectApiName = objectApiName;
        this.editFieldSet = this.getFieldSetName(objectApiName);
        this.isEditModalOpen = true;
    }

    getFieldSetName(objectApiName) {
        switch (objectApiName) {
            case this.parentObjectApiName:
                return this.parentFieldset;
            case this.childObjectApiName:
                return this.childFieldset;
            case this.grandchildObjectApiName:
                return this.grandchildFieldset;
            default:
                return '';
        }
    }
}
