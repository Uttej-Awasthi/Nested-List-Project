import { LightningElement, track, wire, api } from 'lwc';
import getParentRecords from '@salesforce/apex/NestedRelatedListController.getParentRecords';
import getChildRecords from '@salesforce/apex/NestedRelatedListController.getChildRecords';
import getGrandchildRecords from '@salesforce/apex/NestedRelatedListController.getGrandchildRecords';

const actions = [
    { label: 'Show details', name: 'show_details' },
    { label: 'Delete', name: 'delete' },
];

export default class NestedRelatedList extends LightningElement {
    @api parentObjectApiName = 'Account';
    @api childObjectApiName = 'Opportunity';
    @api grandchildObjectApiName = 'OpportunityLineItem';
    @api parentFieldset = 'AccountFieldset';
    @api childFieldset = 'OpportunityFieldset';
    @api grandchildFieldset = 'OpportunityLineItemFieldset';

    @track parentRecords = [];
    @track childRecords = [];
    @track grandchildRecords = [];

    @track parentColumns = [];
    @track childColumns = [];
    @track grandchildColumns = [];

    @track expandedParentId = null;
    @track expandedChildId = null;

    @track record = {};

    connectedCallback() {
        this.loadParentRecords();
    }

    loadParentRecords() {
        getParentRecords({ parentObjectApiName: this.parentObjectApiName, parentFieldset: this.parentFieldset })
            .then(result => {
                this.parentRecords = result.records;
                this.parentColumns = this.createColumns(result.columns);
            })
            .catch(error => {
                console.error('Error fetching parent records', error);
            });
    }

    loadChildRecords() {
        getChildRecords({
            childObjectApiName: this.childObjectApiName,
            parentField: 'AccountId',
            parentId: this.expandedParentId,
            childFieldset: this.childFieldset
        })
            .then(result => {
                this.childRecords = result.records;
                this.childColumns = this.createColumns(result.columns);
            })
            .catch(error => {
                console.error('Error fetching child records', error);
            });
    }

    loadGrandchildRecords() {
        getGrandchildRecords({
            grandchildObjectApiName: this.grandchildObjectApiName,
            childField: 'OpportunityId',
            childId: this.expandedChildId,
            grandchildFieldset: this.grandchildFieldset
        })
            .then(result => {
                this.grandchildRecords = result.records;
                this.grandchildColumns = this.createColumns(result.columns);
            })
            .catch(error => {
                console.error('Error fetching grandchild records', error);
            });
    }

    createColumns(fieldList) {
        let columns = fieldList.map(field => {
            let column = { label: field.label, fieldName: field.fieldName };
            if (['currency', 'number', 'date', 'datetime', 'email', 'phone', 'boolean', 'percent', 'reference', 'textarea', 'url'].includes(field.type)) {
                column.type = field.type;
            }
            return column;
        });
        columns.push({
            type: 'action',
            typeAttributes: { rowActions: actions },
        });
        return columns;
    }

    handleRowAction(event) {
        const actionName = event.detail.action.name;
        const row = event.detail.row;
        switch (actionName) {
            case 'delete':
                this.deleteRow(row, 'parent');
                break;
            case 'show_details':
                this.showRowDetails(row);
                break;
            default:
        }
    }

    handleChildRowAction(event) {
        const actionName = event.detail.action.name;
        const row = event.detail.row;
        switch (actionName) {
            case 'delete':
                this.deleteRow(row, 'child');
                break;
            case 'show_details':
                this.showRowDetails(row);
                break;
            default:
        }
    }

    handleGrandchildRowAction(event) {
        const actionName = event.detail.action.name;
        const row = event.detail.row;
        switch (actionName) {
            case 'delete':
                this.deleteRow(row, 'grandchild');
                break;
            case 'show_details':
                this.showRowDetails(row);
                break;
            default:
        }
    }

    deleteRow(row, level) {
        const { Id } = row;
        let data = [];
        if (level === 'parent') {
            data = this.parentRecords;
        } else if (level === 'child') {
            data = this.childRecords;
        } else if (level === 'grandchild') {
            data = this.grandchildRecords;
        }
        const index = this.findRowIndexById(Id, data);
        if (index !== -1) {
            data = data.slice(0, index).concat(data.slice(index + 1));
            if (level === 'parent') {
                this.parentRecords = data;
            } else if (level === 'child') {
                this.childRecords = data;
            } else if (level === 'grandchild') {
                this.grandchildRecords = data;
            }
        }
    }

    findRowIndexById(id, data) {
        let ret = -1;
        data.some((row, index) => {
            if (row.Id === id) {
                ret = index;
                return true;
            }
            return false;
        });
        return ret;
    }

    showRowDetails(row) {
        this.record = row;
    }
}
