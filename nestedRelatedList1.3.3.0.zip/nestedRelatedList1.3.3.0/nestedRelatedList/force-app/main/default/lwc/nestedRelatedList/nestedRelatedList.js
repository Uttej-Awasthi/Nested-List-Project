import { LightningElement, track, api } from 'lwc';
import { ShowToastEvent } from 'lightning/platformShowToastEvent';
import getParentRecords from '@salesforce/apex/NestedRelatedListController.getParentRecords';
import getChildRecords from '@salesforce/apex/NestedRelatedListController.getChildRecords';
import getGrandchildRecords from '@salesforce/apex/NestedRelatedListController.getGrandchildRecords';
import updateRecord from '@salesforce/apex/NestedRelatedListController.updateRecord';
import deleteRecord from '@salesforce/apex/NestedRelatedListController.deleteRecord';

export default class NestedRelatedList extends LightningElement {
    @api parentObjectApiName;
    @api childObjectApiName;
    @api grandchildObjectApiName;
    @api parentFieldset;
    @api childFieldset;
    @api grandchildFieldset;
    @api parentField; // Field linking child to parent
    @api childField; // Field linking grandchild to child

    @track gridData = [];
    @track gridExpandedRows = [];
    @track parentColumns = [];
    @track originalGridData = [];
    gridLoadingState = false;
    searchKey = '';
    sortedBy;
    sortedDirection;

    connectedCallback() {
        this.loadParentRecords();
    }

    loadParentRecords() {
        getParentRecords({ parentObjectApiName: this.parentObjectApiName, parentFieldset: this.parentFieldset })
            .then(result => {
                const records = result.records.map(record => ({
                    ...record,
                    _children: [], // Initialize children as an empty array
                    hasChildrenContent: false // Flag to check if children are loaded
                }));
                this.gridData = records;
                this.originalGridData = records; // Store original data
                this.parentColumns = this.createColumns(result.columns);
            })
            .catch(error => {
                console.error('Error fetching parent records', error);
            });
    }

    handleRowToggle(event) {
        const rowId = event.detail.name;
        const row = this.findRowById(rowId, this.gridData);
        const hasChildrenContent = row._children.length > 0;

        if (!hasChildrenContent) {
            this.loadChildRecords(rowId);
        }
    }

    loadChildRecords(parentId) {
        this.gridLoadingState = true;

        getChildRecords({
            childObjectApiName: this.childObjectApiName,
            parentField: this.parentField,
            parentId: parentId,
            childFieldset: this.childFieldset
        })
            .then(result => {
                const children = result.records.map(record => ({
                    ...record,
                    _children: [],
                    hasChildrenContent: false
                }));

                this.addChildrenToRow(this.gridData, parentId, children);
                this.gridLoadingState = false;
            })
            .catch(error => {
                console.error('Error fetching child records', error);
                this.gridLoadingState = false;
            });
    }

    loadGrandchildRecords(childId) {
        this.gridLoadingState = true;

        getGrandchildRecords({
            grandchildObjectApiName: this.grandchildObjectApiName,
            childField: this.childField,
            childId: childId,
            grandchildFieldset: this.grandchildFieldset
        })
            .then(result => {
                const grandchildren = result.records;

                this.addChildrenToRow(this.gridData, childId, grandchildren);
                this.gridLoadingState = false;
            })
            .catch(error => {
                console.error('Error fetching grandchild records', error);
                this.gridLoadingState = false;
            });
    }

    addChildrenToRow(data, rowId, children) {
        const newData = data.map(row => {
            if (row.Id === rowId) {
                row._children = children;
            } else if (row._children.length > 0) {
                this.addChildrenToRow(row._children, rowId, children);
            }
            return row;
        });

        this.gridData = newData;
    }

    findRowById(id, data) {
        for (let row of data) {
            if (row.Id === id) {
                return row;
            }
            if (row._children.length > 0) {
                const childRow = this.findRowById(id, row._children);
                if (childRow) {
                    return childRow;
                }
            }
        }
        return null;
    }

    createColumns(fields) {
        return fields.map(field => ({
            label: field.label,
            fieldName: field.fieldName,
            type: field.type,
            sortable: true
        }));
    }

    handleSearch(event) {
        this.searchKey = event.target.value.toLowerCase();
        if (this.searchKey) {
            const filteredData = this.filterData(this.originalGridData, this.searchKey);
            this.gridData = filteredData;
        } else {
            this.gridData = this.originalGridData;
        }
    }

    filterData(data, searchKey) {
        return data
            .map(row => {
                const rowMatches = Object.values(row).some(value =>
                    String(value).toLowerCase().includes(searchKey)
                );

                if (rowMatches) {
                    return row;
                }

                const children = this.filterData(row._children, searchKey);

                if (children.length > 0) {
                    return { ...row, _children: children };
                }

                return null;
            })
            .filter(row => row !== null);
    }

    handleSort(event) {
        const { fieldName: sortedBy, sortDirection: sortedDirection } = event.detail;
        const cloneData = [...this.gridData];
        cloneData.sort(this.sortBy(sortedBy, sortedDirection === 'asc' ? 1 : -1));
        this.gridData = cloneData;
        this.sortedBy = sortedBy;
        this.sortedDirection = sortedDirection;
    }

    sortBy(field, reverse, primer) {
        const key = primer ? x => primer(x[field]) : x => x[field];
        return (a, b) => {
            const aKey = key(a);
            const bKey = key(b);
            return reverse * ((aKey > bKey) - (bKey > aKey));
        };
    }
}
