declare module "@salesforce/apex/NestedRelatedListController.getParentRecords" {
  export default function getParentRecords(param: {parentObjectApiName: any, parentFieldset: any}): Promise<any>;
}
declare module "@salesforce/apex/NestedRelatedListController.getChildRecords" {
  export default function getChildRecords(param: {childObjectApiName: any, parentField: any, parentId: any, childFieldset: any}): Promise<any>;
}
declare module "@salesforce/apex/NestedRelatedListController.getGrandchildRecords" {
  export default function getGrandchildRecords(param: {grandchildObjectApiName: any, childField: any, childId: any, grandchildFieldset: any}): Promise<any>;
}
declare module "@salesforce/apex/NestedRelatedListController.updateRecord" {
  export default function updateRecord(param: {record: any}): Promise<any>;
}
declare module "@salesforce/apex/NestedRelatedListController.deleteRecord" {
  export default function deleteRecord(param: {recordId: any, objectApiName: any}): Promise<any>;
}
declare module "@salesforce/apex/NestedRelatedListController.addRecord" {
  export default function addRecord(param: {record: any}): Promise<any>;
}
