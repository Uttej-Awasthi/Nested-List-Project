// grandchildRelatedList.js
import { LightningElement, api, track } from 'lwc';
import getGrandchildRecords from '@salesforce/apex/NestedRelatedListController.getGrandchildRecords';
import { ShowToastEvent } from 'lightning/platformShowToastEvent';

export default class GrandchildRelatedList extends LightningElement {
    @api childId;
    @api grandchildObjectApiName;
    @api grandchildFieldset;
    @api childField;

    @track columns = [];
    @track grandchildRecords = [];
    @track isLoading = true;

    connectedCallback() {
        this.loadGrandchildRecords();
    }

    loadGrandchildRecords() {
        this.isLoading = true;
        getGrandchildRecords({
            grandchildObjectApiName: this.grandchildObjectApiName,
            childField: this.childField,
            childId: this.childId,
            grandchildFieldset: this.grandchildFieldset
        })
        .then(result => {
            this.columns = result.columns;
            this.grandchildRecords = result.records;
            this.isLoading = false;
        })
        .catch(error => {
            console.error('Error loading grandchild records', error);
            this.showToast('Error', 'Error loading grandchild records: ' + error.body.message, 'error');
            this.isLoading = false;
        });
    }

    showToast(title, message, variant) {
        const event = new ShowToastEvent({
            title: title,
            message: message,
            variant: variant,
        });
        this.dispatchEvent(event);
    }
}