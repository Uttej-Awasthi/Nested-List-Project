// grandchildRelatedList.js
import { LightningElement, api, track } from 'lwc';
import getGrandchildRecords from '@salesforce/apex/NestedRelatedListController.getGrandchildRecords';
import { ShowToastEvent } from 'lightning/platformShowToastEvent';

export default class GrandchildRelatedList extends LightningElement {
    @api childId;
    @api grandchildObjectApiName;
    @api grandchildFieldset;
    @api childField;

    @track columns = [];
    @track grandchildRecords = [];
    @track isLoading = true;
    @track sortBy;
    @track sortDirection = 'asc';

    connectedCallback() {
        this.loadGrandchildRecords();
    }

    loadGrandchildRecords() {
        this.isLoading = true;
        getGrandchildRecords({
            grandchildObjectApiName: this.grandchildObjectApiName,
            childField: this.childField,
            childId: this.childId,
            grandchildFieldset: this.grandchildFieldset
        })
        .then(result => {
            this.columns = this.transformColumns(result.columns);
            this.grandchildRecords = result.records;
            this.isLoading = false;
        })
        .catch(error => {
            console.error('Error loading grandchild records', error);
            this.showToast('Error', 'Error loading grandchild records: ' + error.body.message, 'error');
            this.isLoading = false;
        });
    }

    transformColumns(columns) {
        return columns.map(column => ({
            ...column,
            sortable: true
        }));
    }

    handleSort(event) {
        const { fieldName: sortedBy, sortDirection } = event.detail;
        this.sortBy = sortedBy;
        this.sortDirection = sortDirection;

        this.sortData(this.sortBy, this.sortDirection);
    }

    sortData(fieldName, direction) {
        let parseData = JSON.parse(JSON.stringify(this.grandchildRecords));
        let keyValue = (a) => {
            return a[fieldName];
        };
        let isReverse = direction === 'asc' ? 1 : -1;

        parseData.sort((x, y) => {
            x = keyValue(x) ? keyValue(x) : '';
            y = keyValue(y) ? keyValue(y) : '';
            return isReverse * ((x > y) - (y > x));
        });

        this.grandchildRecords = parseData;
    }

    showToast(title, message, variant) {
        const event = new ShowToastEvent({
            title: title,
            message: message,
            variant: variant,
        });
        this.dispatchEvent(event);
    }
}