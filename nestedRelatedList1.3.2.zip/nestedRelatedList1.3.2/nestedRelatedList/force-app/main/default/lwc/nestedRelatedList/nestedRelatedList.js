import { LightningElement, track, api } from 'lwc';
import getParentRecords from '@salesforce/apex/NestedRelatedListController.getParentRecords';
import getChildRecords from '@salesforce/apex/NestedRelatedListController.getChildRecords';
import getGrandchildRecords from '@salesforce/apex/NestedRelatedListController.getGrandchildRecords';

export default class NestedRelatedList extends LightningElement {
    @api parentObjectApiName = 'Account';
    @api childObjectApiName = 'Opportunity';
    @api grandchildObjectApiName = 'OpportunityLineItem';
    @api parentFieldset = 'AccountFieldset';
    @api childFieldset = 'OpportunityFieldset';
    @api grandchildFieldset = 'OpportunityLineItemFieldset';

    @track gridData = [];
    @track gridExpandedRows = [];
    gridLoadingState = false;

    connectedCallback() {
        this.loadParentRecords();
    }

    loadParentRecords() {
        getParentRecords({ parentObjectApiName: this.parentObjectApiName, parentFieldset: this.parentFieldset })
            .then(result => {
                this.gridData = result.records.map(record => {
                    return {
                        ...record,
                        _children: [], // Initialize children as an empty array
                        hasChildrenContent: false // Flag to check if children are loaded
                    };
                });
                this.parentColumns = this.createColumns(result.columns);
            })
            .catch(error => {
                console.error('Error fetching parent records', error);
            });
    }

    handleRowToggle(event) {
        const rowId = event.detail.name;
        const row = this.findRowById(rowId, this.gridData);
        const hasChildrenContent = row._children.length > 0;

        if (!hasChildrenContent) {
            this.loadChildRecords(rowId);
        }
    }

    loadChildRecords(parentId) {
        this.gridLoadingState = true;

        getChildRecords({
            childObjectApiName: this.childObjectApiName,
            parentField: 'AccountId',
            parentId: parentId,
            childFieldset: this.childFieldset
        })
            .then(result => {
                const children = result.records.map(record => ({
                    ...record,
                    _children: [],
                    hasChildrenContent: false
                }));

                this.addChildrenToRow(this.gridData, parentId, children);
                this.gridLoadingState = false;
            })
            .catch(error => {
                console.error('Error fetching child records', error);
                this.gridLoadingState = false;
            });
    }

    loadGrandchildRecords(childId) {
        this.gridLoadingState = true;

        getGrandchildRecords({
            grandchildObjectApiName: this.grandchildObjectApiName,
            childField: 'OpportunityId',
            childId: childId,
            grandchildFieldset: this.grandchildFieldset
        })
            .then(result => {
                const grandchildren = result.records;

                this.addChildrenToRow(this.gridData, childId, grandchildren);
                this.gridLoadingState = false;
            })
            .catch(error => {
                console.error('Error fetching grandchild records', error);
                this.gridLoadingState = false;
            });
    }

    addChildrenToRow(data, rowId, children) {
        const newData = data.map(row => {
            if (row.Id === rowId) {
                row._children = children;
            } else if (row._children.length > 0) {
                this.addChildrenToRow(row._children, rowId, children);
            }
            return row;
        });

        this.gridData = newData;
    }

    findRowById(id, data) {
        for (let row of data) {
            if (row.Id === id) {
                return row;
            }
            if (row._children.length > 0) {
                const found = this.findRowById(id, row._children);
                if (found) {
                    return found;
                }
            }
        }
        return null;
    }

    createColumns(fieldList) {
        let columns = fieldList.map(field => {
            let column = { label: field.label, fieldName: field.fieldName };
            if (['currency', 'number', 'date', 'datetime', 'email', 'phone', 'boolean', 'percent', 'reference', 'textarea', 'url'].includes(field.type)) {
                column.type = field.type;
            }
            return column;
        });
        columns.push({
            type: 'action',
            typeAttributes: { rowActions: this.actions },
        });
        return columns;
    }
}
