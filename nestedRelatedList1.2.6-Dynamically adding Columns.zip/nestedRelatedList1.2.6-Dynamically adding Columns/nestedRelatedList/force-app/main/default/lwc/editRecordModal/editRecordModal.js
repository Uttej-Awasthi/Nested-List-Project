import { LightningElement, api } from 'lwc';

export default class EditRecordModal extends LightningElement {
    @api recordId;
    @api objectApiName;

    handleSuccess() {
        this.dispatchEvent(new CustomEvent('close'));
    }

    handleCancel() {
        this.dispatchEvent(new CustomEvent('close'));
    }
}
