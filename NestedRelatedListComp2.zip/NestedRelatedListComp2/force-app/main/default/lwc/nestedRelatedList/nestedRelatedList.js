// nestedRelatedList.js
import { LightningElement, api, track } from 'lwc';
import getChildRecords from '@salesforce/apex/NestedRelatedListController.getChildRecords';
import getGrandchildRecords from '@salesforce/apex/NestedRelatedListController.getGrandchildRecords';

export default class NestedRelatedList extends LightningElement {
    @api recordId;
    @api childObjectApiName;
    @api grandchildObjectApiName;
    @api childFieldset;
    @api grandchildFieldset;
    @api parentField;
    @api childField;

    @track columns = [];
    @track flattenedRecords = [];

    connectedCallback() {
        this.loadChildRecords();
    }

    loadChildRecords() {
        getChildRecords({ 
            childObjectApiName: this.childObjectApiName, 
            parentField: this.parentField, 
            parentId: this.recordId, 
            childFieldset: this.childFieldset 
        })
        .then(result => {
            this.columns = result.columns;
            this.processRecords(result.records);
        })
        .catch(error => {
            console.error('Error loading child records', error);
        });
    }

    processRecords(records) {
        this.flattenedRecords = records.map(record => this.createFlattenedRecord(record, false));
    }

    // createFlattenedRecord(record, isGrandchild) {
    //     return {
    //         id: record.Id,
    //         name: isGrandchild ? record.CaseNumber : (record.Name || ''),
    //         hasChildren: !isGrandchild,
    //         isExpanded: false,
    //         buttonIcon: '►',
    //         rowClass: isGrandchild ? 'slds-is-expanded' : 'slds-is-collapsed',
    //         nameClass: isGrandchild ? 'slds-p-left_large' : '',
    //         fields: this.columns.map(column => ({
    //             name: column.fieldName,
    //             value: record[column.fieldName],
    //             label: column.label
    //         })),
    //         isGrandchild: isGrandchild,
    //         _children: []
    //     };
    // }
    createFlattenedRecord(record, isGrandchild) {
        return {
            id: record.Id,
            name: isGrandchild ? record.CaseNumber : (record.Name || ''),
            hasChildren: !isGrandchild,
            isExpanded: false,
            buttonIcon: '►',
            rowClass: isGrandchild ? 'slds-is-expanded' : 'slds-is-collapsed',
            nameClass: isGrandchild ? 'slds-p-left_large' : '',
            fields: this.columns
                .filter(column => column.fieldName !== 'Name')  // Exclude the name field from here
                .map(column => ({
                    name: column.fieldName,
                    value: record[column.fieldName],
                    label: column.label
                })),
            isGrandchild: isGrandchild,
            _children: []
        };
    }

    handleRowToggle(event) {
        const recordId = event.currentTarget.dataset.id;
        const record = this.flattenedRecords.find(r => r.id === recordId);
        if (record) {
            record.isExpanded = !record.isExpanded;
            record.buttonIcon = record.isExpanded ? '▼' : '►';
            record.rowClass = record.isExpanded ? 'slds-is-expanded' : 'slds-is-collapsed';

            if (record.isExpanded && record._children.length === 0) {
                this.loadGrandchildRecords(recordId);
            }

            this.flattenedRecords = [...this.flattenedRecords];
        }
    }

    loadGrandchildRecords(childId) {
        getGrandchildRecords({
            grandchildObjectApiName: this.grandchildObjectApiName,
            childField: this.childField,
            childId: childId,
            grandchildFieldset: this.grandchildFieldset
        })
        .then(result => {
            console.log('Grandchild records:', result);
            this.columns = [...this.columns, ...result.columns.filter(col => !this.columns.some(c => c.fieldName === col.fieldName))];
            const parentIndex = this.flattenedRecords.findIndex(r => r.id === childId);
            if (parentIndex !== -1) {
                const grandchildRecords = result.records.map(record => this.createFlattenedRecord(record, true));
                this.flattenedRecords[parentIndex]._children = grandchildRecords;
                this.flattenedRecords.splice(parentIndex + 1, 0, ...grandchildRecords);
                this.flattenedRecords = [...this.flattenedRecords];
            }
        })
        .catch(error => {
            console.error('Error loading grandchild records', error);
        });
    }
}