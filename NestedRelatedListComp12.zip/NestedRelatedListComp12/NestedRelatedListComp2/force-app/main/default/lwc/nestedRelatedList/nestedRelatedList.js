// nestedRelatedList.js
import { LightningElement, api, track } from 'lwc';
import { ShowToastEvent } from 'lightning/platformShowToastEvent';
import getChildRecords from '@salesforce/apex/NestedRelatedListController.getChildRecords';
import getGrandchildRecords from '@salesforce/apex/NestedRelatedListController.getGrandchildRecords';
import deleteRecord from '@salesforce/apex/NestedRelatedListController.deleteRecord';

export default class NestedRelatedList extends LightningElement {
    @api recordId;
    @api childObjectApiName;
    @api grandchildObjectApiName;
    @api childFieldset;
    @api grandchildFieldset;
    @api parentField;
    @api childField;

    @track columns = [];
    @track flattenedRecords = [];
    @track sortBy = 'Name';
    @track sortDirection = 'asc';
    @track searchTerm = '';
    @track pageNumber = 1;
    @track pageSize = 10;
    @track totalRecords = 0;
    @track isEditModalOpen = false;
    @track recordIdToEdit;
    @track objectApiNameToEdit;

    isResizing = false;
    resizeColumnField = '';
    initialWidth = 0;
    initialX = 0;

    connectedCallback() {
        this.loadChildRecords();
        window.addEventListener('mousemove', this.handleResizeMove.bind(this));
        window.addEventListener('mouseup', this.handleResizeEnd.bind(this));
    }
    
    disconnectedCallback() {
        window.removeEventListener('mousemove', this.handleResizeMove.bind(this));
        window.removeEventListener('mouseup', this.handleResizeEnd.bind(this));
    }

    handleResizeStart(event) {
        this.isResizing = true;
        this.resizeColumnField = event.target.dataset.field;
        this.initialWidth = event.target.parentElement.offsetWidth;
        this.initialX = event.clientX;
        event.preventDefault();
    }
    
    handleResizeMove(event) {
        if (this.isResizing) {
            const diffX = event.clientX - this.initialX;
            const newWidth = this.initialWidth + diffX;
            const column = this.template.querySelector(`th[data-field="${this.resizeColumnField}"]`);
            if (column) {
                column.style.width = `${newWidth}px`;
            }
        }
    }
    
    handleResizeEnd() {
        this.isResizing = false;
        this.resizeColumnField = '';
        this.initialWidth = 0;
        this.initialX = 0;
    }

    loadChildRecords() {
        getChildRecords({ 
            childObjectApiName: this.childObjectApiName, 
            parentField: this.parentField, 
            parentId: this.recordId, 
            childFieldset: this.childFieldset,
            pageSize: this.pageSize,
            pageNumber: this.pageNumber,
            sortBy: this.sortBy,
            sortDirection: this.sortDirection,
            searchTerm: this.searchTerm
        })
        .then(result => {
            this.columns = this.updateColumnsWithSortData(result.columns);
            this.processRecords(result.records);
            this.totalRecords = result.totalRecords;
        })
        .catch(error => {
            console.error('Error loading child records', error);
            this.showToast('Error', 'Error loading child records: ' + error.body.message, 'error');
        });
    }

    updateColumnsWithSortData(columns) {
        return columns.map(column => {
            return {
                ...column,
                sortIconName: this.getSortIconName(column.fieldName),
                sortDirection: this.getSortDirection(column.fieldName),
                sortAssistiveText: this.getSortAssistiveText(column.fieldName)
            };
        });
    }

    getSortIconName(fieldName) {
        if (this.sortBy !== fieldName) {
            return 'utility:arrowdown';
        }
        return this.sortDirection === 'asc' ? 'utility:arrowup' : 'utility:arrowdown';
    }

    getSortDirection(fieldName) {
        return this.sortBy === fieldName ? this.sortDirection : 'none';
    }

    getSortAssistiveText(fieldName) {
        if (this.sortBy !== fieldName) {
            return '';
        }
        return `Sorted ${this.sortDirection === 'asc' ? 'ascending' : 'descending'}`;
    }

    processRecords(records) {
        this.flattenedRecords = records.map(record => this.createFlattenedRecord(record, false, 1));
    }

    createFlattenedRecord(record, isGrandchild, level) {
        return {
            id: record.Id,
            name: isGrandchild ? record.CaseNumber : (record.Name || ''),
            hasChildren: !isGrandchild,
            isExpanded: false,
            buttonIcon: 'utility:chevronright',
            rowClass: `slds-hint-parent ${isGrandchild ? 'slds-is-expanded' : 'slds-is-collapsed'}`,
            nameClass: isGrandchild ? 'slds-p-left_large' : '',
            level: level,
            fields: this.columns
                .filter(column => column.fieldName !== 'Name')
                .map(column => ({
                    name: column.fieldName,
                    value: record[column.fieldName],
                    label: column.label
                })),
            isGrandchild: isGrandchild,
            _children: []
        };
    }

    handleRowToggle(event) {
        const recordId = event.currentTarget.dataset.id;
        const recordIndex = this.flattenedRecords.findIndex(r => r.id === recordId);
        if (recordIndex !== -1) {
            const record = this.flattenedRecords[recordIndex];
            record.isExpanded = !record.isExpanded;
            record.buttonIcon = record.isExpanded ? 'utility:chevrondown' : 'utility:chevronright';
            record.rowClass = `slds-hint-parent ${record.isExpanded ? 'slds-is-expanded' : 'slds-is-collapsed'}`;

            if (record.isExpanded) {
                if (record._children.length === 0) {
                    this.loadGrandchildRecords(recordId, recordIndex);
                } else {
                    this.flattenedRecords.splice(recordIndex + 1, 0, ...record._children);
                }
            } else {
                const childrenCount = record._children.length;
                this.flattenedRecords.splice(recordIndex + 1, childrenCount);
            }

            this.flattenedRecords = [...this.flattenedRecords];
        }
    }

    loadGrandchildRecords(childId, parentIndex) {
        getGrandchildRecords({
            grandchildObjectApiName: this.grandchildObjectApiName,
            childField: this.childField,
            childId: childId,
            grandchildFieldset: this.grandchildFieldset
        })
        .then(result => {
            this.columns = [...this.columns, ...result.columns.filter(col => !this.columns.some(c => c.fieldName === col.fieldName))];
            if (parentIndex !== -1) {
                const grandchildRecords = result.records.map(record => this.createFlattenedRecord(record, true, 2));
                this.flattenedRecords[parentIndex]._children = grandchildRecords;
                this.flattenedRecords.splice(parentIndex + 1, 0, ...grandchildRecords);
                this.flattenedRecords = [...this.flattenedRecords];
            }
        })
        .catch(error => {
            console.error('Error loading grandchild records', error);
            this.showToast('Error', 'Error loading grandchild records: ' + error.body.message, 'error');
        });
    }

    handleSort(event) {
        const fieldName = event.currentTarget.dataset.field;
        if (this.sortBy === fieldName) {
            this.sortDirection = this.sortDirection === 'asc' ? 'desc' : 'asc';
        } else {
            this.sortBy = fieldName;
            this.sortDirection = 'asc';
        }
        this.loadChildRecords();
    }

    handleSearch(event) {
        this.searchTerm = event.target.value;
        this.loadChildRecords();
    }

    handleRowAction(event) {
        const action = event.detail.value;
        const recordId = event.currentTarget.dataset.recordId;

        if (action === 'edit') {
            this.editRecord(recordId);
        } else if (action === 'delete') {
            // Check if the record is a child or grandchild record
            const record = this.flattenedRecords.find(r => r.id === recordId);
            if (record.isGrandchild) {
                this.deleteGrandchildRecord(recordId);
            } else {
                this.deleteChildRecord(recordId);
            }
        }
    }

    editRecord(recordId) {
        this.recordIdToEdit = recordId;
        this.objectApiNameToEdit = this.childObjectApiName; // Assuming editing the child record, adjust if needed
        this.isEditModalOpen = true;
    }

    closeModal() {
        this.isEditModalOpen = false;
        this.loadChildRecords(); // Reload records after successful edit
    }

    deleteChildRecord(recordId) {
        deleteRecord({ recordId: recordId, objectApiName: this.childObjectApiName })
        .then(() => {
            this.showToast('Success', 'Child record deleted successfully.', 'success');
            this.loadChildRecords(); // Reload the child records to reflect the deletion
        })
        .catch(error => {
            console.error('Error deleting child record', error);
            this.showToast('Error', 'Error deleting child record: ' + error.body.message, 'error');
        });
    }

    deleteGrandchildRecord(recordId) {
        deleteRecord({ recordId: recordId, objectApiName: this.grandchildObjectApiName })
        .then(() => {
            this.showToast('Success', 'Grandchild record deleted successfully.', 'success');
            this.loadChildRecords(); // Reload the child records to reflect the deletion
        })
        .catch(error => {
            console.error('Error deleting grandchild record', error);
            this.showToast('Error', 'Error deleting grandchild record: ' + error.body.message, 'error');
        });
    }

    handlePrevious() {
        if (this.pageNumber > 1) {
            this.pageNumber -= 1;
            this.loadChildRecords();
        }
    }

    handleNext() {
        if (this.pageNumber < Math.ceil(this.totalRecords / this.pageSize)) {
            this.pageNumber += 1;
            this.loadChildRecords();
        }
    }

    showToast(title, message, variant) {
        const event = new ShowToastEvent({
            title: title,
            message: message,
            variant: variant,
        });
        this.dispatchEvent(event);
    }
}
