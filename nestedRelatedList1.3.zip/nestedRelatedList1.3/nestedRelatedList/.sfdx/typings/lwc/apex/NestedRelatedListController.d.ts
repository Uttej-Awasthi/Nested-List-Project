declare module "@salesforce/apex/NestedRelatedListController.getParentRecords" {
  export default function getParentRecords(param: {parentObjectApiName: any, parentFieldset: any}): Promise<any>;
}
declare module "@salesforce/apex/NestedRelatedListController.getChildRecords" {
  export default function getChildRecords(param: {childObjectApiName: any, parentField: any, parentId: any, childFieldset: any}): Promise<any>;
}
declare module "@salesforce/apex/NestedRelatedListController.getGrandchildRecords" {
  export default function getGrandchildRecords(param: {grandchildObjectApiName: any, childField: any, childId: any, grandchildFieldset: any}): Promise<any>;
}
