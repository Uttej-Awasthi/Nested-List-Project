// NestedRelatedListController.js
import { LightningElement, track, wire, api } from 'lwc';
import getParentRecords from '@salesforce/apex/NestedRelatedListController.getParentRecords';
import getChildRecords from '@salesforce/apex/NestedRelatedListController.getChildRecords';
import getGrandchildRecords from '@salesforce/apex/NestedRelatedListController.getGrandchildRecords';

export default class NestedRelatedList extends LightningElement {
    @api parentObjectApiName = 'Account';
    @api childObjectApiName = 'Opportunity';
    @api grandchildObjectApiName = 'OpportunityLineItem';
    @api parentFieldset = 'AccountFieldset';
    @api childFieldset = 'OpportunityFieldset';
    @api grandchildFieldset = 'OpportunityLineItemFieldset';

    @track parentRecords = [];
    @track childRecords = [];
    @track grandchildRecords = [];

    @track parentColumns = [];
    @track childColumns = [];
    @track grandchildColumns = [];

    @track expandedParentId = null;
    @track expandedChildId = null;

    connectedCallback() {
        this.loadParentRecords();
    }

    loadParentRecords() {
        getParentRecords({ parentObjectApiName: this.parentObjectApiName, parentFieldset: this.parentFieldset })
            .then(result => {
                this.parentRecords = result.records;
                this.parentColumns = this.createColumns(result.columns);
            })
            .catch(error => {
                console.error('Error fetching parent records', error);
            });
    }

    loadChildRecords() {
        getChildRecords({
            childObjectApiName: this.childObjectApiName,
            parentField: 'AccountId',
            parentId: this.expandedParentId,
            childFieldset: this.childFieldset
        })
            .then(result => {
                this.childRecords = result.records;
                this.childColumns = this.createColumns(result.columns);
            })
            .catch(error => {
                console.error('Error fetching child records', error);
            });
    }

    loadGrandchildRecords() {
        getGrandchildRecords({
            grandchildObjectApiName: this.grandchildObjectApiName,
            childField: 'OpportunityId',
            childId: this.expandedChildId,
            grandchildFieldset: this.grandchildFieldset
        })
            .then(result => {
                this.grandchildRecords = result.records;
                this.grandchildColumns = this.createColumns(result.columns);
            })
            .catch(error => {
                console.error('Error fetching grandchild records', error);
            });
    }

    createColumns(fieldList) {
        let columns = fieldList.map(field => {
            let column = { label: field.label, fieldName: field.fieldName };
            if (['currency', 'number', 'date', 'datetime', 'email', 'phone', 'boolean', 'percent', 'reference', 'textarea', 'url'].includes(field.type)) {
                column.type = field.type;
            }
            return column;
        });
        columns.push({
            type: 'button',
            typeAttributes: {
                label: 'Show Related',
                name: 'show_related',
                iconName: 'utility:chevronright',
                variant: 'brand'
            }
        });
        return columns;
    }

    handleRowAction(event) {
        const row = event.detail.row;
        this.expandedParentId = row.Id;
        this.loadChildRecords();
    }

    handleChildRowAction(event) {
        const row = event.detail.row;
        this.expandedChildId = row.Id;
        this.loadGrandchildRecords();
    }
}
