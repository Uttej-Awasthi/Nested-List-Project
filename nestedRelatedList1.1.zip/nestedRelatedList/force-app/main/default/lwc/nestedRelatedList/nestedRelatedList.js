import { LightningElement, track, wire, api } from 'lwc';
import getParentRecords from '@salesforce/apex/NestedRelatedListController.getParentRecords';
import getChildRecords from '@salesforce/apex/NestedRelatedListController.getChildRecords';
import getGrandchildRecords from '@salesforce/apex/NestedRelatedListController.getGrandchildRecords';

export default class NestedRelatedList extends LightningElement {
    @api parentObjectApiName = 'Account';
    @api childObjectApiName = 'Opportunity';
    @api grandchildObjectApiName = 'OpportunityLineItem';
    @api parentFieldset = 'AccountFieldset';
    @api childFieldset = 'OpportunityFieldset';
    @api grandchildFieldset = 'OpportunityLineItemFieldset';

    @track parentRecords = [];
    @track childRecords = [];
    @track grandchildRecords = [];

    @track expandedParentId = null;
    @track expandedChildId = null;

    parentColumns = [
        { label: 'Name', fieldName: 'Name' },
        { label: 'Industry', fieldName: 'Industry' },
        { label: 'Annual Revenue', fieldName: 'AnnualRevenue', type: 'currency' },
        {
            type: 'button', typeAttributes: {
                label: 'Show Opportunities',
                name: 'show_opportunities',
                iconName: 'utility:chevronright',
                variant: 'brand'
            }
        }
    ];

    childColumns = [
        { label: 'Name', fieldName: 'Name' },
        { label: 'Amount', fieldName: 'Amount', type: 'currency' },
        { label: 'Stage', fieldName: 'StageName' },
        {
            type: 'button', typeAttributes: {
                label: 'Show Products',
                name: 'show_products',
                iconName: 'utility:chevronright',
                variant: 'brand'
            }
        }
    ];

    grandchildColumns = [
        { label: 'Opportunity Product Name', fieldName: 'Name' },
        { label: 'Product', fieldName: 'Product2Id' },
        { label: 'Quantity', fieldName: 'Quantity', type: 'number' },
        { label: 'Unit Price', fieldName: 'UnitPrice', type: 'currency' },
        { label: 'Total Price', fieldName: 'TotalPrice', type: 'currency' }
    ];

    connectedCallback() {
        this.loadParentRecords();
    }

    loadParentRecords() {
        getParentRecords({ parentObjectApiName: this.parentObjectApiName, parentFieldset: this.parentFieldset })
            .then(result => {
                this.parentRecords = result;
            })
            .catch(error => {
                console.error('Error fetching parent records', error);
            });
    }

    handleRowAction(event) {
        const row = event.detail.row;
        this.expandedParentId = row.Id;
        this.loadChildRecords();
    }

    loadChildRecords() {
        getChildRecords({
            childObjectApiName: this.childObjectApiName,
            parentField: 'AccountId',
            parentId: this.expandedParentId,
            childFieldset: this.childFieldset
        })
            .then(result => {
                this.childRecords = result;
            })
            .catch(error => {
                console.error('Error fetching child records', error);
            });
    }

    handleChildRowAction(event) {
        const row = event.detail.row;
        this.expandedChildId = row.Id;
        this.loadGrandchildRecords();
    }

    loadGrandchildRecords() {
        getGrandchildRecords({
            grandchildObjectApiName: this.grandchildObjectApiName,
            childField: 'OpportunityId',
            childId: this.expandedChildId,
            grandchildFieldset: this.grandchildFieldset
        })
            .then(result => {
                this.grandchildRecords = result;
            })
            .catch(error => {
                console.error('Error fetching grandchild records', error);
            });
    }
}
