import { LightningElement, track, api } from 'lwc';
import getParentRecords from '@salesforce/apex/NestedRelatedListController.getParentRecords';
import getChildRecords from '@salesforce/apex/NestedRelatedListController.getChildRecords';
import getGrandchildRecords from '@salesforce/apex/NestedRelatedListController.getGrandchildRecords';
import updateRecord from '@salesforce/apex/NestedRelatedListController.updateRecord';
import deleteRecord from '@salesforce/apex/NestedRelatedListController.deleteRecord';

export default class NestedRelatedList extends LightningElement {
    @api parentObjectApiName = 'Account';
    @api childObjectApiName = 'Opportunity';
    @api grandchildObjectApiName = 'OpportunityLineItem';
    @api parentFieldset = 'AccountFieldset';
    @api childFieldset = 'OpportunityFieldset';
    @api grandchildFieldset = 'OpportunityLineItemFieldset';

    @track gridData = [];
    @track gridExpandedRows = [];
    @track parentColumns = [];
    @track originalGridData = [];
    gridLoadingState = false;
    searchKey = '';
    sortedBy;
    sortedDirection;

    connectedCallback() {
        this.loadParentRecords();
    }

    loadParentRecords() {
        getParentRecords({ parentObjectApiName: this.parentObjectApiName, parentFieldset: this.parentFieldset })
            .then(result => {
                const records = result.records.map(record => ({
                    ...record,
                    _children: [], // Initialize children as an empty array
                    hasChildrenContent: false // Flag to check if children are loaded
                }));
                this.gridData = records;
                this.originalGridData = records; // Store original data
                this.parentColumns = this.createColumns(result.columns);
            })
            .catch(error => {
                console.error('Error fetching parent records', error);
            });
    }

    handleRowToggle(event) {
        const rowId = event.detail.name;
        const row = this.findRowById(rowId, this.gridData);
        const hasChildrenContent = row._children.length > 0;

        if (!hasChildrenContent) {
            this.loadChildRecords(rowId);
        }
    }

    loadChildRecords(parentId) {
        this.gridLoadingState = true;

        getChildRecords({
            childObjectApiName: this.childObjectApiName,
            parentField: 'AccountId',
            parentId: parentId,
            childFieldset: this.childFieldset
        })
            .then(result => {
                const children = result.records.map(record => ({
                    ...record,
                    _children: [],
                    hasChildrenContent: false
                }));

                this.addChildrenToRow(this.gridData, parentId, children);
                this.gridLoadingState = false;
            })
            .catch(error => {
                console.error('Error fetching child records', error);
                this.gridLoadingState = false;
            });
    }

    loadGrandchildRecords(childId) {
        this.gridLoadingState = true;

        getGrandchildRecords({
            grandchildObjectApiName: this.grandchildObjectApiName,
            childField: 'OpportunityId',
            childId: childId,
            grandchildFieldset: this.grandchildFieldset
        })
            .then(result => {
                const grandchildren = result.records;

                this.addChildrenToRow(this.gridData, childId, grandchildren);
                this.gridLoadingState = false;
            })
            .catch(error => {
                console.error('Error fetching grandchild records', error);
                this.gridLoadingState = false;
            });
    }

    addChildrenToRow(data, rowId, children) {
        const newData = data.map(row => {
            if (row.Id === rowId) {
                row._children = children;
            } else if (row._children.length > 0) {
                this.addChildrenToRow(row._children, rowId, children);
            }
            return row;
        });

        this.gridData = newData;
    }

    findRowById(id, data) {
        for (let row of data) {
            if (row.Id === id) {
                return row;
            }
            if (row._children.length > 0) {
                const found = this.findRowById(id, row._children);
                if (found) {
                    return found;
                }
            }
        }
        return null;
    }

    handleRowAction(event) {
        const actionName = event.detail.action.name;
        const row = event.detail.row;
        switch (actionName) {
            case 'edit':
                this.editRecord(row);
                break;
            case 'delete':
                this.deleteRecord(row);
                break;
            default:
                break;
        }
    }

    editRecord(row) {
        // Implement edit logic here
        updateRecord({ record: row })
            .then(() => {
                this.loadParentRecords(); // Reload data to reflect changes
            })
            .catch(error => {
                console.error('Error updating record', error);
            });
    }

    deleteRecord(row) {
        deleteRecord({ recordId: row.Id, objectApiName: this.parentObjectApiName })
            .then(() => {
                this.loadParentRecords(); // Reload data to reflect changes
            })
            .catch(error => {
                console.error('Error deleting record', error);
            });
    }

    createColumns(fieldList) {
        let columns = fieldList.map(field => {
            let column = { label: field.label, fieldName: field.fieldName };
            if (['currency', 'number', 'date', 'datetime', 'email', 'phone', 'boolean', 'percent', 'reference', 'textarea', 'url'].includes(field.type)) {
                column.type = field.type;
            }
            return column;
        });
        columns.push({
            type: 'action',
            typeAttributes: { rowActions: this.actions },
        });
        return columns;
    }

    handleSearch(event) {
        this.searchKey = event.target.value;
        if (this.searchKey) {
            this.filterData();
        } else {
            this.gridData = this.originalGridData; // Reset to original data
        }
    }

    filterData() {
        const searchKey = this.searchKey.toLowerCase();
        const data = JSON.parse(JSON.stringify(this.originalGridData)); // Use original data for filtering

        const filteredData = data.filter(record => {
            return Object.keys(record).some(key => {
                if (record[key] && typeof record[key] === 'string') {
                    return record[key].toLowerCase().includes(searchKey);
                }
                return false;
            });
        });

        this.gridData = filteredData;
    }

    handleSort(event) {
        const { fieldName: sortedBy, sortDirection } = event.detail;
        this.sortedBy = sortedBy;
        this.sortedDirection = sortDirection;
        this.sortData(sortedBy, sortDirection);
    }

    sortData(fieldName, sortDirection) {
        const compare = (a, b) => {
            const aValue = a[fieldName];
            const bValue = b[fieldName];
            return aValue > bValue ? 1 : -1;
        };

        const data = JSON.parse(JSON.stringify(this.gridData));
        data.sort(compare);
        if (sortDirection === 'desc') {
            data.reverse();
        }
        this.gridData = data;
    }

    actions = [
        { label: 'Edit', name: 'edit' },
        { label: 'Delete', name: 'delete' }
    ];
}
